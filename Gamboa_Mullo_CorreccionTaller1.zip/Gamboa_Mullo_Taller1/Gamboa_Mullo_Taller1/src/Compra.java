import java.util.LinkedList;
import java.util.Queue;

public class Compra {
    private Ruta ruta;
    public String nombre;
    public String cedula;
    public int boletos;
    private double preciofinal;

    public Compra(Ruta ruta, String nombre, String cedula, int boletos, double preciofinal) {
        this.ruta = ruta;
        this.nombre = nombre;
        this.cedula = cedula;
        this.boletos = boletos;
        this.preciofinal = preciofinal;
    }

    public String getCedula() {
        return cedula;
    }

    public int getBoletos() {
        return boletos;
    }



    @Override
    public String toString() {
        return "Compra " +
                "ruta: " + ruta +
                ", nombre: " + nombre +
                ", cedula: " + cedula +
                ", boletos: " + boletos +
                ", Precio Final: " + preciofinal + "\n";
    }
}
