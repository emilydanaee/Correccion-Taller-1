import java.util.LinkedList;
import java.util.Queue;

public class ColaCompra {
    public Queue<Compra> cola;

    public ColaCompra(){
        cola = new LinkedList<>();
    }

    public void encolar(Compra compra){
        cola.add(compra);
    }

    public Queue<Compra> getCola() {
        return cola;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(Compra compra:cola){
            sb.append(compra);
        }
        return sb.toString();
    }

}
