public class Ruta {
    private String nombreRuta;
    private double precioPorBoleto;
    private int boletosDisponibles;
    private int boletosVendidos;
    private double totalVenta;

    public Ruta(String nombreRuta, double precioPorBoleto){
        this.nombreRuta = nombreRuta;
        this.precioPorBoleto = precioPorBoleto;
        this.totalVenta = 0;
        this.boletosDisponibles = 20;
        this.boletosVendidos = 0;
    }

    public String getNombre() {
        return nombreRuta;
    }

    public double getPrecioPorBoleto() {
        return precioPorBoleto;
    }

    public int getBoletosDisponibles() {
        return boletosDisponibles;
    }

    public int getBoletosVendidos() {
        return boletosVendidos;
    }

    public double getTotal(double precioRuta){
        totalVenta += precioRuta;
        return totalVenta;
    }

    public void venderBoletos(int boletos) {
        this.boletosVendidos += boletos;
        this.boletosDisponibles -= boletos;
    }

    public String toString() {
        return nombreRuta;
    }
}

