import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static java.lang.Integer.parseInt;

public class Ventana {
    private JComboBox cboRutas;
    private JTextField txtNombre;
    private JTextField txtCedula;
    private JTextField txtBoletos;
    private JButton btnComprar;
    private JTextArea txtCompraRealizada;
    private JLabel txtDisponibles;
    private JLabel txtVendidas;
    private JLabel txtTotal;
    private JPanel Principal;
    private ColaCompra cola = new ColaCompra();
    private ArrayList<Ruta> rutas = new ArrayList<>();


    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public Ventana() {
        Ruta rutaQuitoGuayaquil = new Ruta("QUITO - GUAYAQUIL", 10.50);
        Ruta rutaQuitoCuenca = new Ruta("QUITO - CUENCA", 12.75);
        Ruta rutaQuitoLoja = new Ruta("QUITO - LOJA", 15.00);

        rutas.add(rutaQuitoGuayaquil);
        rutas.add(rutaQuitoCuenca);
        rutas.add(rutaQuitoLoja);

        btnComprar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rutaElegida = cboRutas.getSelectedItem().toString();
                String nombre = txtNombre.getText();
                String cedula = txtCedula.getText();
                int numBoletos = parseInt(txtBoletos.getText());
                double precioFinal = 0;

                int total = 0;
                for (Compra compra : cola.getCola()) {
                    if (compra.getCedula().equals(cedula)) {
                        total += compra.getBoletos();
                        if (total + numBoletos > 5) {
                            JOptionPane.showMessageDialog(null, "Cada pasajero solo puede comprar un máximo de 5 boletos en total.");
                            return;
                        }
                    }
                }

                if (numBoletos < 1 || numBoletos > 5) {
                    JOptionPane.showMessageDialog(null, "Solo puedes comprar de 1 a 5 boletos");
                    return;
                }

                Ruta ruta = null;
                for (Ruta r : rutas) {
                    if (r.getNombre().equals(rutaElegida)) {
                        ruta = r;
                        if (ruta.getBoletosDisponibles() < numBoletos) {
                            JOptionPane.showMessageDialog(null, "No hay suficientes boletos disponibles para esta ruta.");
                            return;
                        }
                        precioFinal = numBoletos * r.getPrecioPorBoleto();
                        r.venderBoletos(numBoletos);
                        txtDisponibles.setText(Integer.toString(r.getBoletosDisponibles()));
                        txtVendidas.setText(Integer.toString(r.getBoletosVendidos()));
                        txtTotal.setText(Double.toString(r.getTotal(precioFinal)));

                    }
                }

                Compra compra = new Compra(ruta, nombre, cedula, numBoletos, precioFinal);
                cola.encolar(compra);
                txtCompraRealizada.setText(cola.toString());
                System.out.println(compra);
            }
        });
    }
}
